
var leimnud = new maborak;