tinyMCE.addI18n('en.ccSimpleUploader', {
    desc:"Upload File to Server"
});
