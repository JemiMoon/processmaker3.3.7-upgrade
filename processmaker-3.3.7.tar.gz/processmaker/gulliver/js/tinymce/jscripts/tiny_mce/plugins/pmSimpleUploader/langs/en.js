tinyMCE.addI18n('en.pmSimpleUploader', {
    desc:"Upload File to Server"
});
